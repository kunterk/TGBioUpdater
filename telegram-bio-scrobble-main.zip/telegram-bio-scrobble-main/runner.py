#!/usr/bin/env python3
"""
Process runner with exponential backoff.

Features:
- Automatic restart on crash
- Exponential backoff (5s → 10s → 20s... → 300s max)
- Smart reset: backoff resets if app runs > 60s
- Crash loop prevention
"""

import time
import subprocess
import sys

MAX_BACKOFF = 300      # Maximum backoff: 5 minutes
INITIAL_BACKOFF = 5    # Initial backoff: 5 seconds
RUNTIME_THRESHOLD = 60 # Reset backoff if app runs > 60s

def run_app():
    """Run main.py with exponential backoff."""
    backoff = INITIAL_BACKOFF
    
    while True:
        print(f"[RUNNER] Memulakan main.py...", flush=True)
        start_time = time.time()
        
        # Run main.py
        try:
            process = subprocess.Popen([sys.executable, "main.py"])
            exit_code = process.wait()
        except Exception as e:
            print(f"[RUNNER] Gagal memulakan main.py: {e}", flush=True)
            exit_code = -1
        
        runtime = time.time() - start_time
        print(f"[RUNNER] main.py terhenti (Exit Code: {exit_code}, Runtime: {round(runtime, 2)}s)", flush=True)

        # Reset backoff if app ran successfully for > 60s
        if runtime > RUNTIME_THRESHOLD:
            print(f"[RUNNER] App berjalan stabil ({round(runtime, 2)}s). Reset backoff.", flush=True)
            backoff = INITIAL_BACKOFF
        else:
            # Increase backoff exponentially (up to MAX_BACKOFF)
            next_backoff = min(backoff * 2, MAX_BACKOFF)
            print(f"[RUNNER] Backoff meningkat: {backoff}s → {next_backoff}s", flush=True)
            backoff = next_backoff

        print(f"[RUNNER] Berehat {backoff}s sebelum memulakan semula...", flush=True)
        time.sleep(backoff)

if __name__ == "__main__":
    try:
        run_app()
    except KeyboardInterrupt:
        print("\n[RUNNER] Bot dihentikan oleh pengguna (Ctrl+C).", flush=True)
        sys.exit(0)
    except Exception as e:
        print(f"\n[RUNNER] Ralat kritikal: {e}", flush=True)
        sys.exit(1)
